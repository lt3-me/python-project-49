### Hexlet tests and linter status:
[![Actions Status](https://github.com/lt3-me/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/lt3-me/python-project-49/actions)

<a href="https://codeclimate.com/github/lt3-me/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/a272327a6e563f6a1a6b/maintainability" /></a>
### brain-even
<a href="https://asciinema.org/a/7Z2VCcsTo5nbvZ4kUufeCr2FH" target="_blank"><img src="https://asciinema.org/a/7Z2VCcsTo5nbvZ4kUufeCr2FH.svg" /></a>
### brain-calc
<a href="https://asciinema.org/a/UnYdxE7eJUb0i0hyUYEhZjMwU" target="_blank"><img src="https://asciinema.org/a/UnYdxE7eJUb0i0hyUYEhZjMwU.svg" /></a>
### brain-gcd
<a href="https://asciinema.org/a/6uSQaN7aeVQLPJkHQG8spD0MW" target="_blank"><img src="https://asciinema.org/a/6uSQaN7aeVQLPJkHQG8spD0MW.svg" /></a>
