#!/usr/bin/env python3
from brain_games.games.prime_game import start_prime


def main():
    start_prime()


if __name__ == '__main__':
    main()
