#!/usr/bin/env python3
from brain_games.games.progression_game import start_prog


def main():
    start_prog()


if __name__ == '__main__':
    main()
