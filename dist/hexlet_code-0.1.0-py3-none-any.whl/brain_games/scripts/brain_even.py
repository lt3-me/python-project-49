#!/usr/bin/env python3
from brain_games.games.even_game import start_even


def main():
    start_even()


if __name__ == '__main__':
    main()
